import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
                                        // configuração para inicialização da pagina 
  display = '0';                        // variavel display inicia com 0
  valor: number = null;              //  variavel valor, tipo numerico, iniciando vazio
  operador: any = null;               //  variavel operador, tipo qualquer, iniciado como vazio
  auxiliar = false;                  // variavel auxiliar, tipo boleana  
  ativador = false;                 //  variavel auxiliar para ativar o botão ac e c
  virgula = false;                    //  variavel virgula , para decisiva para numero inteiro ou float

  constructor() {}



click(btn: any) {    /// quando clicado botão executa switch
  switch (btn) {
    case 'ac':
      this.display = '0';
      this.valor = null;
      this.operador = null;
      this.auxiliar = false;
      break;
    case 'c':
      this.display = '0';
      this.ativador = false;
      break;
    case '+/-':
      if (Math.sign(parseInt(this.display, 0)) === 1) {
        const sign = -Math.abs(parseInt(this.display, 0));
        this.display = sign.toString();
      } else if (Math.sign(parseInt(this.display, 0)) === -1) {
        const sign = Math.abs(parseInt(this.display, 0));
        this.display = sign.toString();
      } else {
        this.display = this.display;
      }
      break;
    case '%':
      this.addpercentual();
      break;
    case ':':
      this.addoperador('/');
      break;
    case 'X':
      this.addoperador('X');
      break;
    case '-':
      this.addoperador('-');
      break;
    case '+':
      this.addoperador('+');
      break;
    case '=':
      if (this.valor !== null && this.operador !== null) {
        this.calculadora();
      }
      this.operador = null;
      break;
    case '0':
      this.addnumero('0');
      break;
    case '1':
      this.addnumero('1');
      break;
    case '2':
      this.addnumero('2');
      break;
    case '3':
      this.addnumero('3');
      break;
    case '4':
      this.addnumero('4');
      break;
    case '5':
      this.addnumero('5');
      break;
    case '6':
      this.addnumero('6');
      break;
    case '7':
      this.addnumero('7');
      break;
    case '8':
      this.addnumero('8');
      break;
    case '9':
      this.addnumero('9');
      break;
    case ',':
      this.addvirgula();
      break;
  }
}
addvirgula() {
  if (this.virgula === false) { // caso botão virgula não seja precionado,  
    this.virgula = true;        // virgula recebe verdadeiro   
  } else {
    this.virgula = false;       //  virgula recebe falso
  }
}
addnumero(acumulador: string) {
  if (acumulador === '0') {
    if (this.auxiliar === true) {
      this.display = acumulador;
      this.auxiliar = false;
    } else if (this.display !== '0') {
      if (this.virgula === true) {
        this.display = `${this.display.toString()}.${acumulador}`;
      } else {
        this.display = this.display.toString() + acumulador;
      }
    } else if (this.display === '0') {
      if (this.virgula === true) {
        this.display = `${this.display.toString()}.${acumulador}`;
      }
    }
  } else {
    if (this.auxiliar === true) {
      this.display = acumulador;
      this.auxiliar = false;
    } else if (this.display === '0') {
      if (this.virgula === true) {
        if (this.display.toString().indexOf('.') > -1) {
          this.display = this.display.toString() + acumulador;
        } else {
          this.display = `${this.display.toString()}.${acumulador}`;
        }
      } else {
        this.display = acumulador;
      }
    } else {
      if (this.virgula === true) {
        if (this.display.toString().indexOf('.') > -1) {
          this.display = this.display.toString() + acumulador;
        } else {
          this.display = `${this.display.toString()}.${acumulador}`;
        }
      } else {
        this.display = this.display.toString() + acumulador;
      }
    }
  }
  this.ativador = true;
}

addoperador(op: string) { 
  if (this.auxiliar === false) {
    if (this.valor === null) {
      if (this.virgula === true) {
        this.valor = parseFloat(this.display);
      } else {
        this.valor = parseInt(this.display, 0);
      }
    }
    if (this.valor !== null && this.operador !== null) {
      this.calculadora();
    }
  }
  this.virgula = false;
  this.operador = op;
  this.auxiliar = true;
}

addpercentual() {    // calcula o porcentagem
  this.virgula = false;
  const dispval = parseInt(this.display, 0) / 100;
  this.display = dispval.toString();
}
calculadora() {   // inicio do switch de operadores
  switch (this.operador) {
    case ':':   // utilizado : pois / não realiza o calculo
      if (this.virgula === true) {
        this.valor = (this.valor / parseFloat(this.display));
      } else {
        this.valor = (this.valor / parseInt(this.display, 0));
      }
      break;
    case 'X':
      if (this.virgula === true) {
        this.valor = (this.valor * parseFloat(this.display));
      } else {
        this.valor = (this.valor * parseInt(this.display, 0));
      }
      break;
    case '-':
      if (this.virgula === true) {
        this.valor = (this.valor - parseFloat(this.display));
      } else {
        this.valor = (this.valor - parseInt(this.display, 0));
      }
      break;
    case '+':
      if (this.virgula === true) {
        this.valor = (this.valor + parseFloat(this.display));
      } else {
        this.valor = (this.valor + parseInt(this.display, 0));
      }
      break;
  }
  this.display = this.valor.toString();
}
}